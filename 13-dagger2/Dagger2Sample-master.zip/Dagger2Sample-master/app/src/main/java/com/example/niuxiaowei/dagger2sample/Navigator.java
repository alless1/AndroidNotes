package com.example.niuxiaowei.dagger2sample;

import javax.inject.Inject;
import javax.inject.Singleton;

/**
 * Created by niuxiaowei on 16/3/19.
 */
@Singleton
public class Navigator {

    public Navigator(){

    }
}
