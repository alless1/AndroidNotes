package com.example.niuxiaowei.dagger2sample.data;

/**
 * Created by niuxiaowei on 16/3/22.
 */
public class UserData {

    public String mUserName;
}
