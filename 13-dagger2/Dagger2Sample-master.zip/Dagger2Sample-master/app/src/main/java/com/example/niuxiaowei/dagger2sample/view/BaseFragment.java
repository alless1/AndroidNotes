package com.example.niuxiaowei.dagger2sample.view;

import android.app.Fragment;

/**
 * Created by niuxiaowei on 16/3/22.
 */
public class BaseFragment extends Fragment{
}
