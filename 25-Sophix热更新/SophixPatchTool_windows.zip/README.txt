SophixPatchTool

欢迎使用阿里巴巴Sophix热更新补丁生成工具

可根据自身开发平台选择工具，目前支持macOS，Windows，Linux。

注意事项：
1. 使用本工具务必安装Java，且JDK版本至少为7，安装后请正确设置Windows的Path环境变量。
2. MAC下需要把本工具移到“应用程序”（/Applications/）目录下，否则可能崩溃。
3、Linux下使用Ubuntu 16.04 64bit最佳。
4、工具会自动根据代码的变更情况选择冷启动或者热替换方式的修复。
5、如果热替换发生崩溃，可以勾选上强制冷启动方式打包更加稳定。

更多使用详情请访问：https://help.aliyun.com/document_detail/53247.html

还可以加入钉钉群：11711603 与我们交流
